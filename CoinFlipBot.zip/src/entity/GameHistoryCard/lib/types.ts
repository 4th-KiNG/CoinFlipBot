export interface Game {
  value?: string
  date?: number
  userAddress?: string
  isWin?: boolean
  event?: string
  lt?: number
}