export interface AppDialogProps {
  id: number
  open: boolean
  onClose: () => void
}
