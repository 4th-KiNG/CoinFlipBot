export interface BaseModalHandles {
    closeWithDelay: () => void;
}